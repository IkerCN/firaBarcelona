<?php 
    define("URL", "http://localhost/firaBarcelona/firaBarcelona/");
    define("action_default","index");
?>
<?php 
    define("URL", "/");
    define("action_default","index");
?>
En la carpeta "Documentacion" estan el moodboard, la documentació del projecte i el fitxer de l'exportació de la base de dades de la web.
